package com.example.vaccination.myInterface;

public interface FirebaseDataUploadCallback {
    void isSuccess(boolean isSuccess);
}
