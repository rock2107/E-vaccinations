package com.example.vaccination.myInterface;

public interface ProfileDataReceived {
    void dataReceived(Object object,boolean success);
}

