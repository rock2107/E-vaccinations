package com.example.vaccination.data;

public enum Counter {
    REQUESTCOUNTER, USERCOUNTER
}
