package com.example.vaccination.myInterface;

public interface FirebaseDataUpdated {
    void dataUpdated(boolean status, Exception e);
}
