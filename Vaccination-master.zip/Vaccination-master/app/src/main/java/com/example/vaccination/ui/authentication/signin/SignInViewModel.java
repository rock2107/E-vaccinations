package com.example.vaccination.ui.authentication.signin;

import androidx.lifecycle.ViewModel;

public class SignInViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}