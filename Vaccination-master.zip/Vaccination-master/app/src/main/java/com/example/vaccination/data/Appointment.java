package com.example.vaccination.data;

public class Appointment {
}
