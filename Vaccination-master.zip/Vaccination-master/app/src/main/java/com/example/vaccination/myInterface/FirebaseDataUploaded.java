package com.example.vaccination.myInterface;

public interface FirebaseDataUploaded {
    void dataUploaded(boolean success);
}
