package com.example.vaccination.myInterface;

import java.util.List;

public interface FirebaseListData {
    void dataReceived(List<?> list,boolean success);
}
